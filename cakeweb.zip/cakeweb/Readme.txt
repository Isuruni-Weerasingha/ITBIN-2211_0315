How to run the Car Washing  Management System Project Using PHP and MySQL



.Open PHPMyAdmin (http://localhost/phpmyadmin)

.Create a database with name cwmsdb

.Import cwmsdb.sql file(given inside the zip package in SQL file folder)

.Run the script http://localhost/cwms

Admin Credential
Username: admin
Password: Test@123
