<?php //error_reporting(0);
include('includes/config.php'); 

if(isset($_POST['book']))
{
    $ctype=$_POST['cakeType'];
    $cshop=$_POST['cakeshops'];   
    $fname=$_POST['fname'];
    $mobile=$_POST['contactno'];
    $date=$_POST['orderDate'];
    //$time=$_POST['caketime'];
    $message=$_POST['message'];
    $status='New';
    $bno=mt_rand(100000000, 999999999);
    $sql="INSERT INTO tblcakebooking(bookingId,cakeType,cakeshop,fullName,mobileNumber,orderDate,message,status) VALUES(:bno,:ctype,:cshop,:fname,:mobile,:date,:message,:status)";
    $query = $dbh->prepare($sql);
$query->bindParam(':bno',$bno,PDO::PARAM_STR);
$query->bindParam(':ctype',$ctype,PDO::PARAM_STR);
$query->bindParam(':cshop',$cshop,PDO::PARAM_STR);
$query->bindParam(':fname',$fname,PDO::PARAM_STR);
$query->bindParam(':mobile',$mobile,PDO::PARAM_STR);
$query->bindParam(':date',$date,PDO::PARAM_STR);
//$query->bindParam(':time',$time,PDO::PARAM_STR);
$query->bindParam(':message',$message,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
 
  echo '<script>alert("Your booking done successfully. Booking number is "+"'.$bno.'")</script>';
 echo "<script>window.location.href ='cake_price.php'</script>";
}
else 
{
 echo "<script>alert('Something went wrong. Please try again.');</script>";
}

}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>CWMS | Cake Plans</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Free Website Template" name="keywords">
        <meta content="Free Website Template" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
    
        <?php include_once('includes/header.php');?>
        
        <!-- Page Header Start -->
        <div class="page-header">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h2>Cake Designs</h2>
                    </div>
                    <div class="col-12">
                        <a href="index.php">Home</a>
                        <a href="cake_price.php">Price</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page Header End -->
        
        
        <!-- Price Start -->
        <div class="price">
            <div class="container">
                <div class="section-header text-center">
                    <p>Cake Designs</p>
                    <h2>Choose Your Cake</h2>
                </div>
                <div class="row">

                    <div class="col-md-4">
                        <div class="price-item">
                            <div class="price-header">
                                <h3>Birthday Cakes</h3>
                                <h3><span>Rs</span><strong>2750.00</strong><span>LKR</span></h3>
                            </div>
                            <div class="price-img">
                            
                               <img src="img/birthday.jpeg" alt="Image">
                             
                            </div>
                            <br><br>
                            <div class="price-footer">
                                <a class="btn btn-custom"  data-toggle="modal" data-target="#myModal">Book Now</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="price-item">
                            <div class="price-header">
                                <h3>Wedding/Anniversary Cakes</h3>
                                <h3><span>Rs</span><strong>5050.00</strong><span>LKR</span></h3>
                            </div>
                            <div class="price-img">
                            
                            <img src="img/weddingcake2.jpeg" alt="Image">
                          
                         </div>
                         <br><br>
                            <div class="price-footer">
                                <a class="btn btn-custom" data-toggle="modal" data-target="#myModal">Book Now</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="price-item">
                            <div class="price-header">
                                <h3>Cup Cakes</h3>
                                <h3><span>Rs</span><strong>500.00</strong><span>LKR</span></h3>
                            </div>
                            <div class="price-img">
                            
                               <img src="img/cupcak.jpeg" alt="Image">
                             
                            </div>
                            <br><br>
                            <div class="price-footer">
                                <a class="btn btn-custom" data-toggle="modal" data-target="#myModal">Book Now</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="price-item">
                            <div class="price-header">
                                <h3>Customer Design Cakes</h3>
                                <h3><span>Rs</span><strong>2500.00</strong><span>LKR</span></h3>
                            </div>
                            <div class="price-img">
                            
                               <img src="img/customize.jpeg" alt="Image">
                             
                            </div>
                            <br><br>
                            <div class="price-footer">
                                <a class="btn btn-custom"  data-toggle="modal" data-target="#myModal">Book Now</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="price-item">
                            <div class="price-header">
                                <h3>Bento cake</h3>
                                <h3><span>Rs</span><strong>1800.00</strong><span>LKR</span></h3>
                            </div>
                            <div class="price-img">
                            
                               <img src="img/bento1.jpeg" alt="Image">
                             
                            </div>
                            <br><br>
                            <div class="price-footer">
                                <a class="btn btn-custom"  data-toggle="modal" data-target="#myModal">Book Now</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="price-item">
                            <div class="price-header">
                                <h3>Ribon Cakes</h3>
                                <h3><span>Rs</span><strong>1600.00</strong><span>LKR</span></h3>
                            </div>
                            <div class="price-img">
                            
                               <img src="img/ribbon.jpeg" alt="Image">
                             
                            </div>
                            <br><br>
                            <div class="price-footer">
                                <a class="btn btn-custom"  data-toggle="modal" data-target="#myModal">Book Now</a>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- Price End -->
        
       <?php include_once('includes/footer.php');?>

<!--Model-->
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Cake Creation Booking</h4>
        </div>
        <div class="modal-body">
<form method="post">   
  <p>
            <select name="cakeType" required class="form-control">
                <option value="">Cake Type</option>
                 <option value="1">Birthday Cakes (Rs2750.00LKR)</option>
                 <option value="2">Wedding/Anniversary Cakes (Rs5050.00LKR)</option>
                 <option value="3">Cup Cakes(Rs500.00LKR)</option>
                 <option value="4">Customer Design Cakes(Rs2500.00LKR)</option>
                 <option value="5">Bento cake(Rs1800.00LKR)</option>
                 <option value="6">Ribon Cakes(Rs1600.00LKR)</option>

              </select>

          <p>
            <select name="cakeshops" required class="form-control">
                <option value="">Select Cake Shop</option>
<?php $sql = "SELECT * from tblcakeshop";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
foreach($results as $result)
{               ?>  
    <option value="<?php echo htmlentities($result->id);?>"><?php echo htmlentities($result->cakeShopName);?> (<?php echo htmlentities($result->cakeShopAddress);?>)</option>
<?php } ?>
            </select></p>
            <p><input type="text" name="fname" class="form-control" required placeholder="Full Name"></p>
            <p><input type="text" name="contactno" class="form-control" pattern="[0-9]{10}" title="10 numeric characters only" required placeholder="Mobile No."></p>
            <p>Order Date <br /><input type="date" name="61 422 297 267" required class="form-control"></p>
             <!-- <p>Wash Time <br /><input type="time" name="washtime" required class="form-control"></p> -->
             <p><textarea name="message"  class="form-control" placeholder="Your Message"></textarea></p>
             <p><input type="submit" class="btn btn-custom" name="book" value="Book Now"></p>
      </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>


        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/counterup/counterup.min.js"></script>
        
        <!-- Contact Javascript File -->
        <script src="mail/jqBootstrapValidation.min.js"></script>
        <script src="mail/contact.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
    </body>
</html>
