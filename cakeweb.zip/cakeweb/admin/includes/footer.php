<div class="copyrights">
	 <p>© <?php echo date('Y');?> CAKES. All Rights Reserved |  <a href="#">CAKES</a> </p>
</div>	
